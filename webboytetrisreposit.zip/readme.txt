slight edit of tetris game made by "Tech With Tim"

original url:https://www.youtube.com/watch?v=uoR4ilCWwKA

directions:

unpack included zip files to tetris directory...

install pygame

run main.py

OR if you don't have/want to install python, just run included main.exe

game keys:

left right down arrow keys:move tetris piecce
up arrow key:rotate tetris piece
s:toggle slow mode 
p:toggle pause mode